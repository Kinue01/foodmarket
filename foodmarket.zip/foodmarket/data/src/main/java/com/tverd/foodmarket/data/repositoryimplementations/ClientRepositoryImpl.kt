package com.tverd.foodmarket.data.repositoryimplementations

import com.tverd.foodmarket.data.mappers.ClientRegMapper
import com.tverd.foodmarket.data.repository.client.ClientApiRepository
import com.tverd.foodmarket.data.repository.client.ClientRoomRepository
import com.tverd.foodmarket.domain.model.Client
import com.tverd.foodmarket.domain.model.ClientLogin
import com.tverd.foodmarket.domain.model.ClientRegistration
import com.tverd.foodmarket.domain.repository.ClientRepository

class ClientRepositoryImpl(
    private val clientRoomRepository: ClientRoomRepository,
    private val clientApiRepository: ClientApiRepository,
    private val clientRegMapper: ClientRegMapper
) : ClientRepository {

    override suspend fun addClient(data: ClientRegistration): Boolean {
        return if (clientApiRepository.addClient(data) && clientRoomRepository.saveClient(data)) {
            true
        } else
            false
    }

    override suspend fun checkClient(): Boolean {
        return clientRoomRepository.isCached()
    }

    override suspend fun getClient(data: ClientLogin): Client {
        if (checkClient())
            return clientRoomRepository.getLastClient()
        else {
            val res = clientApiRepository.getClientEmailPass(data)
            clientRoomRepository.saveClient(clientRegMapper.mapFromClient(res))
            return res
        }
    }

    override suspend fun deleteClient(): Boolean {
        return clientRoomRepository.deleteClient()
    }

    override suspend fun getClientFromRoom(): Client {
        return clientRoomRepository.getLastClient()
    }
}