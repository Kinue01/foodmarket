package com.tverd.foodmarket.domain.model

class Paytype(
    val typeId: Int = 0,
    val typeName: String = ""
)