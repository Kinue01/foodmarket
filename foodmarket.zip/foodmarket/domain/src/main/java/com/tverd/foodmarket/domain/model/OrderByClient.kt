package com.tverd.foodmarket.domain.model

class OrderByClient(
    val orderClientId: Int = 0,
    val orderPaytypeId: Int = 0,
    val orderProdId: Int = 0,
    val orderProdCount: Int = 0
)