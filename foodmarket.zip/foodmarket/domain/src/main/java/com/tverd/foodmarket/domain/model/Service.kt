package com.tverd.foodmarket.domain.model

import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable

class Service(
    val service_id: Int = 0,
    val service_name: String = "",
    val service_image: String = ""
)