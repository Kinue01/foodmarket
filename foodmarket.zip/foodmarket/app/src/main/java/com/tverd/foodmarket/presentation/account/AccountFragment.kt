package com.tverd.foodmarket.presentation.account

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.transition.Visibility
import com.tverd.foodmarket.R
import com.tverd.foodmarket.domain.model.Client
import org.koin.androidx.viewmodel.ext.android.viewModel

class AccountFragment : Fragment(R.layout.fragment_account) {

    private val vm by viewModel<AccountViewModel>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        vm.checkClient().invokeOnCompletion {
            if (vm.isClient.value == true) {
                view.findViewById<TextView>(R.id.clientFname).text = vm.client.value!!.clientFirstName
                view.findViewById<TextView>(R.id.clientLname).text = vm.client.value!!.clientLastName
                view.findViewById<TextView>(R.id.clientEmail).text = vm.client.value!!.clientEmail
                view.findViewById<TextView>(R.id.clientPhone).text = vm.client.value!!.clientPhone
                view.findViewById<TextView>(R.id.clientAddress).text = vm.client.value!!.clientAddress
                view.findViewById<Button>(R.id.btnAccLogin).visibility = View.INVISIBLE
                view.findViewById<Button>(R.id.btnAccReg).visibility = View.INVISIBLE
                view.findViewById<Button>(R.id.btnLogout).visibility = View.VISIBLE
            }
            else {
                view.findViewById<Button>(R.id.btnAccLogin).visibility = View.VISIBLE
                view.findViewById<Button>(R.id.btnAccReg).visibility = View.VISIBLE
                view.findViewById<Button>(R.id.btnLogout).visibility = View.INVISIBLE
            }
        }

        view.findViewById<Button>(R.id.btnLogout).setOnClickListener {
            vm.logout().invokeOnCompletion {
                vm.client.value = Client()
                vm.isClient.value = false

                findNavController().navigate(AccountFragmentDirections.actionAccountFragmentToLoginFragment())
            }
        }

        view.findViewById<Button>(R.id.btnAccLogin).setOnClickListener {
            findNavController().navigate(AccountFragmentDirections.actionAccountFragmentToLoginFragment())
        }

        view.findViewById<Button>(R.id.btnAccReg).setOnClickListener{
            findNavController().navigate(AccountFragmentDirections.actionAccountFragmentToRegistrationFragment())
        }
    }
}