package com.tverd.foodmarket.presentation.settings

import androidx.lifecycle.ViewModel

class SettingsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}