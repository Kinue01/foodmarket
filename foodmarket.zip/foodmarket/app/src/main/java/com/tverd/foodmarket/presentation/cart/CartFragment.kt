package com.tverd.foodmarket.presentation.cart

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tverd.foodmarket.R
import com.tverd.foodmarket.adapter.CartAdapter
import org.koin.androidx.viewmodel.ext.android.viewModel

class CartFragment : Fragment(R.layout.fragment_cart) {

    private val vm by viewModel<CartViewModel>()
    private val cartAdapter by lazy { CartAdapter(findNavController(), vm) }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<RecyclerView>(R.id.rvCart).apply {
            layoutManager = LinearLayoutManager(context)
            adapter = cartAdapter
        }

        vm.getCartItems().invokeOnCompletion {
            cartAdapter.differ.submitList(vm.prods.value)
        }

        view.findViewById<Button>(R.id.btnCart).setOnClickListener {
            findNavController().navigate(CartFragmentDirections.actionCartFragmentToOrderFragment(0, 0))
        }
    }

}