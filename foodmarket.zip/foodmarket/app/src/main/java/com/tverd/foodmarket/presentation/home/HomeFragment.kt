package com.tverd.foodmarket.presentation.home

import android.os.Bundle
import android.view.MotionEvent
import androidx.fragment.app.Fragment
import android.view.View
import androidx.lifecycle.viewModelScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tverd.foodmarket.R
import com.tverd.foodmarket.adapter.ProductAdapter
import com.tverd.foodmarket.databinding.FragmentHomeBinding
import kotlinx.coroutines.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class HomeFragment : Fragment(R.layout.fragment_home) {

    private val vm by viewModel<HomeViewModel>()
    private val productAdapter by lazy { ProductAdapter(findNavController()) }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<RecyclerView>(R.id.rvProduct).apply {
            layoutManager = Flex
            adapter = productAdapter
        }

        vm.getProds().invokeOnCompletion {
            productAdapter.differ.submitList(vm.list.value)
        }

    }
}