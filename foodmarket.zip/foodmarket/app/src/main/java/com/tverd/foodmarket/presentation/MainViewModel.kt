package com.tverd.foodmarket.presentation

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tverd.foodmarket.domain.usecases.DeleteRoomProductsUseCase
import kotlinx.coroutines.launch

class MainViewModel(
    private val deleteRoomProductsUseCase: DeleteRoomProductsUseCase
) : ViewModel() {

    fun delProds() = viewModelScope.launch {
        deleteRoomProductsUseCase.execute()
    }

}