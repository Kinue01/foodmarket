package com.tverd.foodmarket.presentation.login

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.lifecycle.viewModelScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.tverd.foodmarket.R
import com.tverd.foodmarket.domain.model.ClientLogin
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import org.koin.androidx.viewmodel.ext.android.viewModel
import kotlin.math.log

class LoginFragment : Fragment(R.layout.fragment_login) {

    private val vm by viewModel<LoginViewModel>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val login = view.findViewById<Button>(R.id.btnLogin)
        val register = view.findViewById<Button>(R.id.btnRegister)

        login.setOnClickListener {
            vm.clientLog.value = ClientLogin(
                view.findViewById<EditText>(R.id.emailInp).text.toString(),
                view.findViewById<EditText>(R.id.passInp).text.toString()
            )


            vm.getClient().invokeOnCompletion {
                findNavController().navigate(LoginFragmentDirections.actionLoginFragmentToAccountFragment())
            }
        }

        register.setOnClickListener {
            findNavController().navigate(LoginFragmentDirections.actionLoginFragmentToRegistrationFragment())
        }
    }
}