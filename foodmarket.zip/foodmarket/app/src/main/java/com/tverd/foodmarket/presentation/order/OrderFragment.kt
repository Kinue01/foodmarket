package com.tverd.foodmarket.presentation.order

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.NumberPicker
import android.widget.Spinner
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.tverd.foodmarket.R
import com.tverd.foodmarket.domain.model.Client
import com.tverd.foodmarket.domain.model.Paytype
import org.koin.androidx.viewmodel.ext.android.viewModel
import kotlin.math.E

class OrderFragment : Fragment(R.layout.fragment_order) {

    private val vm by viewModel<OrderViewModel>()
    private val args by navArgs<OrderFragmentArgs>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        vm.getTypes().invokeOnCompletion {
            val types = mutableListOf<String>()
            vm.paytypes.value!!.map {
                types.add(it.typeName)
            }
            view.findViewById<Spinner>(R.id.orderPaytypeId).apply {
                adapter = ArrayAdapter(this.context, android.R.layout.simple_spinner_item, types)
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                        vm.paytype.value = vm.paytypes.value!![position]
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {
                        TODO("Not yet implemented")
                    }
                }
            }
        }

        vm.checkClient().invokeOnCompletion {
            if (vm.isClient.value!!) {
                view.findViewById<EditText>(R.id.orderFirstname).apply {
                    setText(vm.client.value!!.clientFirstName)
                    isEnabled = false
                }
                view.findViewById<EditText>(R.id.orderLastname).apply {
                    setText(vm.client.value!!.clientLastName)
                    isEnabled = false
                }
                view.findViewById<EditText>(R.id.orderMiddlename).apply {
                    setText(vm.client.value!!.clientMiddleName)
                    isEnabled = false
                }
                view.findViewById<EditText>(R.id.orderPhone).apply {
                    setText(vm.client.value!!.clientPhone)
                    isEnabled = false
                }
                view.findViewById<EditText>(R.id.orderAddress).apply {
                    setText(vm.client.value!!.clientAddress)
                }
            }
        }

        view.findViewById<Button>(R.id.btnAdd).setOnClickListener {
            if (args.from == 0) {
                if (vm.isClient.value!!) {
                    vm.addOrders().invokeOnCompletion {
                        Toast.makeText(context, "Заказ успешно составлен", Toast.LENGTH_SHORT).show()
                        findNavController().navigate(OrderFragmentDirections.actionOrderFragmentToHomeFragment())
                    }
                }
                else {
                    vm.client.value = Client(
                        0,
                        "",
                        "",
                        view.findViewById<EditText>(R.id.orderFirstname).text.toString(),
                        view.findViewById<EditText>(R.id.orderLastname).text.toString(),
                        view.findViewById<EditText>(R.id.orderMiddlename).text.toString(),
                        view.findViewById<EditText>(R.id.orderPhone).text.toString(),
                        view.findViewById<EditText>(R.id.orderAddress).text.toString()
                    )
                    vm.addOrders().invokeOnCompletion {
                        Toast.makeText(context, "Заказ успешно составлен", Toast.LENGTH_SHORT).show()
                        findNavController().navigate(OrderFragmentDirections.actionOrderFragmentToHomeFragment())
                    }
                }
            }
            else {
                if (vm.isClient.value!!) {
                    vm.addOrder(args.id).invokeOnCompletion {
                        Toast.makeText(context, "Заказ успешно составлен", Toast.LENGTH_SHORT).show()
                        findNavController().navigate(OrderFragmentDirections.actionOrderFragmentToHomeFragment())
                    }
                }
                else {
                    vm.client.value = Client(
                        0,
                        "",
                        "",
                        view.findViewById<EditText>(R.id.orderFirstname).text.toString(),
                        view.findViewById<EditText>(R.id.orderLastname).text.toString(),
                        view.findViewById<EditText>(R.id.orderMiddlename).text.toString(),
                        view.findViewById<EditText>(R.id.orderPhone).text.toString(),
                        view.findViewById<EditText>(R.id.orderAddress).text.toString()
                    )
                    vm.addOrder(args.id).invokeOnCompletion {
                        Toast.makeText(context, "Заказ успешно составлен", Toast.LENGTH_SHORT).show()
                        findNavController().navigate(OrderFragmentDirections.actionOrderFragmentToHomeFragment())
                    }
                }
            }
        }

    }

}