package com.tverd.foodmarket.presentation.registration

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.lifecycle.viewModelScope
import androidx.navigation.fragment.findNavController
import com.tverd.foodmarket.R
import com.tverd.foodmarket.domain.model.ClientRegistration
import kotlinx.coroutines.launch
import org.koin.androidx.viewmodel.ext.android.viewModel

class RegistrationFragment : Fragment(R.layout.fragment_registration) {

    private val vm by viewModel<RegistrationViewModel>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<Button>(R.id.btnRegister).setOnClickListener {

            vm.client.value = ClientRegistration(
                view.findViewById<EditText>(R.id.clientFname).text.toString(),
                view.findViewById<EditText>(R.id.clientLname).text.toString(),
                view.findViewById<EditText>(R.id.clientPassword).text.toString(),
                view.findViewById<EditText>(R.id.clientMname).text.toString(),
                view.findViewById<EditText>(R.id.clientPhone).text.toString(),
                view.findViewById<EditText>(R.id.clientAddress).text.toString(),
                view.findViewById<EditText>(R.id.clientEmail).text.toString()
            )

            vm.addClient().invokeOnCompletion {
                findNavController().navigate(RegistrationFragmentDirections.actionRegistrationFragmentToLoginFragment())
            }
        }
    }
}