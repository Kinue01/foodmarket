package com.tverd.foodmarket.utils

import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ProductSpanSizeLookup(
    private val spanCount: Int
) : GridLayoutManager.SpanSizeLookup() {
    override fun getSpanSize(p0: Int): Int {
        val count = listOf(listOf(2, 0), listOf(1, 1))
        val tmp = p0 % spanCount
        return count[spanCount - 1][tmp]
    }
}