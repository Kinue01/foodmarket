package com.tverd.foodmarket.remote.utils

object Constants {
    public val IMG_URL = "http://myfavormusic.free.nf/img/"
}