package com.tverd.foodmarket.roomdb.repositoryimplementation

import com.tverd.foodmarket.data.mappers.ClientRegMapper
import com.tverd.foodmarket.data.repository.client.ClientRoomRepository
import com.tverd.foodmarket.domain.model.Client
import com.tverd.foodmarket.domain.model.ClientLogin
import com.tverd.foodmarket.domain.model.ClientRegistration
import com.tverd.foodmarket.roomdb.dao.ClientDao
import com.tverd.foodmarket.roomdb.mappers.ClientEntityMapper

class ClientRoomRepositoryImpl(
    private val clientDao: ClientDao,
    private val clientEntityMapper: ClientEntityMapper,
    private val clientRegMapper: ClientRegMapper
) : ClientRoomRepository {
    override suspend fun getLastClient(): Client {
        val res = clientDao.getLastClient()
        return if (res != null) {
            clientEntityMapper.mapFromEntity(res)
        }
        else {
            Client()
        }
    }

    override suspend fun saveClient(clientRegistration: ClientRegistration): Boolean {
        clientDao.saveClient(clientEntityMapper.mapToEntity(clientRegMapper.mapToClient(clientRegistration)))

        if (clientDao.getLastClient().clientEmail == clientRegistration.client_email) {
            return true
        }
        else {
            return false
        }
    }

    override suspend fun isCached(): Boolean {
        return clientDao.getClients().isNotEmpty()
    }

    override suspend fun deleteClient(): Boolean {
        clientDao.deleteClient()

        return if (isCached())
            false
        else
            true
    }
}