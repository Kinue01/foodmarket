package com.tverd.foodmarket.roomdb.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.tverd.foodmarket.roomdb.dao.CartDao
import com.tverd.foodmarket.roomdb.dao.ClientDao
import com.tverd.foodmarket.roomdb.dao.ProductDao
import com.tverd.foodmarket.roomdb.dao.ServiceDao
import com.tverd.foodmarket.roomdb.model.CartEntity
import com.tverd.foodmarket.roomdb.model.ClientEntity
import com.tverd.foodmarket.roomdb.model.ProductEntity
import com.tverd.foodmarket.roomdb.model.ServiceEntity

@Database(entities = [ClientEntity::class, ProductEntity::class, ServiceEntity::class, CartEntity::class], version = 3)
abstract class FoodDatabase : RoomDatabase() {

    abstract fun clientDao(): ClientDao

    abstract fun productDao(): ProductDao

    abstract fun serviceDao(): ServiceDao

    abstract fun cartDao(): CartDao

}